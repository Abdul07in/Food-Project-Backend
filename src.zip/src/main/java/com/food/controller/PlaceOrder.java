package com.food.controller;

import java.io.IOException;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.food.dao.CartDaoImpl;
import com.food.dao.OrderDaoImpl;
import com.food.pojo.Cart;
import com.food.pojo.Customer;
import com.food.pojo.Order;

@WebServlet("/PlaceOrder")
public class PlaceOrder extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		OrderDaoImpl oImpl = new OrderDaoImpl();
		Order order = null;
		HttpSession session = request.getSession();
		Customer customer = (Customer) session.getAttribute("currentUser");

		Double billingAmount = Double.parseDouble(request.getParameter("total"));
		LocalDate orderDate = LocalDate.now();
		LocalDateTime currentTime = LocalDateTime.now();
		LocalDateTime nextTime = currentTime.plusDays(1).withHour(16).withMinute(30);
		
		order = new Order(billingAmount, orderDate, customer.getCustomerEmail(), customer.getCustomerAddress(), nextTime,
				"Pending");
		
		if(oImpl.placeOrder(order, 1)) {
			CartDaoImpl cartDaoImpl = new CartDaoImpl();
			List<Cart> clist = cartDaoImpl.showMyCart(customer.getCustomerEmail());
			clist.forEach(cart ->{
				cartDaoImpl.addCartForAdmin(cart);
			});
			cartDaoImpl.clearMyCart(customer.getCustomerEmail());
			response.sendRedirect("profile.jsp");
		}else {
			response.sendRedirect("checkout.jsp");
		}
		
		

	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
