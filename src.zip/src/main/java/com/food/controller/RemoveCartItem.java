package com.food.controller;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.food.dao.CartDaoImpl;

@WebServlet("/RemoveCartItem")
public class RemoveCartItem extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		CartDaoImpl cdi = new CartDaoImpl();
		Integer cartId = Integer.parseInt(request.getParameter("cartId"));
		
		if(cdi.deleteCart(cartId)) {
			response.sendRedirect("cart.jsp");
		}else {
			response.sendRedirect("Error.jsp");
		}
		
		
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
