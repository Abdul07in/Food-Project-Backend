package com.food.controller;

import java.io.IOException;
import java.util.Map;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.food.dao.CartDaoImpl;
import com.food.pojo.Cart;

@WebServlet("/AddToCart")
public class AddToCart extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		Integer foodQuantity = Integer.parseInt(request.getParameter("foodQuantity"));
		Integer foodId = Integer.parseInt(request.getParameter("item"));
		String customerEmail = request.getParameter("user");
		CartDaoImpl cdi = new CartDaoImpl();
		Cart cart = null;
		Double price = null;
		Double subtotal = null;

		Map<Double, Double> map = cdi.getSubtotalMap(foodId, foodQuantity);

		for (Map.Entry<Double, Double> entry : map.entrySet()) {
			price = entry.getKey();
			subtotal = entry.getValue();
		}

		cart = new Cart(foodId, foodQuantity, price, subtotal, customerEmail);

		if (cdi.addCart(cart)) {
			response.sendRedirect("shop.jsp");
		} else {
			response.sendRedirect("error_404.jsp");
		}

//		response.sendRedirect("shop.jsp");

	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		doGet(request, response);
	}

}
