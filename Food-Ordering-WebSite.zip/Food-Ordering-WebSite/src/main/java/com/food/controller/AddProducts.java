package com.food.controller;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.Part;

import com.food.dao.FoodDaoImpl;
import com.food.pojo.Food;

@WebServlet("/AddProducts")
@MultipartConfig
public class AddProducts extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
	FoodDaoImpl fdi = new FoodDaoImpl();

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		PrintWriter out = response.getWriter();

		String foodName = request.getParameter("foodName");
		String foodType = request.getParameter("foodType");
		Double foodPrice = Double.parseDouble(request.getParameter("foodPrice"));
		Integer foodQuantity = Integer.parseInt(request.getParameter("foodQuantity"));
		String foodCategory = request.getParameter("foodType");
		String foodDescription = request.getParameter("foodDescription");
		Integer foodRating = Integer.parseInt(request.getParameter("foodRating"));
	
		Part foodImage = request.getPart("foodImage");
		String fileName = foodImage.getSubmittedFileName();

		Food food = new Food(foodName, foodType, foodPrice, foodQuantity, foodCategory, foodDescription, foodRating,
				fileName);
		
		if (fdi.addFood(food)) {
			out.println("Success");
		} else {
			out.println("Error");
		}
		
		try {
			InputStream inputStream = foodImage.getInputStream();
			byte[] data = new byte[inputStream.available()];
			inputStream.read(data);

			String path = request.getRealPath("/") + "images" + File.separator + fileName;
			
			FileOutputStream fos = new FileOutputStream(path);
			fos.write(data);
			fos.close();
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		


	}

}
