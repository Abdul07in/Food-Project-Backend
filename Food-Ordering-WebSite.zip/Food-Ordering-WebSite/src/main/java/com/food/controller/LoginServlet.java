package com.food.controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.food.dao.CustomerDaoImpl;
import com.food.dao.LoginDaoImpl;
import com.food.pojo.Customer;

@WebServlet("/LoginServlet")
public class LoginServlet extends HttpServlet {

	private static final long serialVersionUID = -365484372760861163L;

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {

		LoginDaoImpl login = new LoginDaoImpl();
		CustomerDaoImpl cust = new CustomerDaoImpl();

		PrintWriter out = resp.getWriter();
		resp.setContentType("text/plain");

		String email = req.getParameter("Email").trim();
		String password = req.getParameter("Password").trim();

		if (login.checkAdmin(email, password)) {
			HttpSession session = req.getSession();
			session.setAttribute("admin", "admin");
			out.print("Admin");			
		} else {
			if (login.checkCustomer(email, password)) {
				Customer customer = cust.searchCustomerByEmail(email);
				HttpSession session = req.getSession();
				session.setAttribute("currentUser", customer);
				out.println("Success");
			} else {
				out.println("User Not Found");
			}
		}

	}
}
