package com.food.controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.food.dao.CustomerDaoImpl;
import com.food.pojo.Customer;

@WebServlet("/RegisterServlet")
public class RegisterServlet extends HttpServlet {

	private static final long serialVersionUID = 1952777201878525112L;

	CustomerDaoImpl cimpl = new CustomerDaoImpl();
	Customer c = null;

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {

		PrintWriter out = resp.getWriter();
		resp.setContentType("text/plain");

		String firstName = req.getParameter("FirstName");
		String lastName = req.getParameter("LastName");
		String name = firstName.trim() + " " + lastName.trim();
		String address = req.getParameter("Address");
		String emailId = req.getParameter("Email");
		String password = req.getParameter("Password");
		String number = req.getParameter("PhoneNumber");
		Long phoneNumber = Long.parseLong(number);
		

		if (cimpl.checkEmail(emailId) || cimpl.checkPhone(phoneNumber)) {
			out.print("Email Or Phone Already Existed");
		} else {
			c = new Customer(name, address, emailId, phoneNumber, password);
			if (cimpl.addCustomer(c)) {
				out.println("Success");
			} else {
				out.println("Error");
			}
		}

	}
}
