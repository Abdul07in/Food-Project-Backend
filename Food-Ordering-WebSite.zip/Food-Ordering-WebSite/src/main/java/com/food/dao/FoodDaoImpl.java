package com.food.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import com.food.pojo.Food;
import com.food.utility.DBConnection;

public class FoodDaoImpl implements FoodDao {

	Scanner sc = new Scanner(System.in);
	Connection con = null;
	String sql = null;
	PreparedStatement pst = null;
	ResultSet rs = null;
	Food f = null;
	List<Food> flist = null;

	Integer foodId;
	String foodName;
	String foodType;
	Double foodPrice;
	Integer foodQuantity;
	String foodCategory;
	String foodDescription;
	Integer foodRating;
	String foodImage;

	@Override
	public boolean addFood(Food f) {

		try {
			con = DBConnection.makeConnection();
			sql = "INSERT INTO `Food_Maj`(`foodName`, `foodType`, `foodPrice`, `foodQuantity`, `foodCategory`, `foodDescription`, `foodRating`, `foodImage`) VALUES (?,?,?,?,?,?,?,?);";

			pst = con.prepareStatement(sql);

			pst.setString(1, f.getFoodName());
			pst.setString(2, f.getFoodType());
			pst.setDouble(3, f.getFoodPrice());
			pst.setInt(4, f.getFoodQuantity());
			pst.setString(5, f.getFoodCategory());
			pst.setString(6, f.getFoodDescription());
			pst.setInt(7, f.getFoodRating());
			pst.setString(8, f.getFoodImage());

			int i = pst.executeUpdate();

			if (i > 0)
				return true;

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				pst.close();
				con.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}

		return false;
	}

	@Override
	public boolean updateFood(Food f) {

		try {
			con = DBConnection.makeConnection();
			sql = "UPDATE `Food_Maj` SET `foodName`=?,`foodType`=?,`foodPrice`=?,`foodQuantity`=?,`foodCategory`=?,`foodDescription`= ?,`foodRating`=? WHERE `foodId`= ?";
			pst = con.prepareStatement(sql);

			pst.setString(1, f.getFoodName());
			pst.setString(2, f.getFoodType());
			pst.setDouble(3, f.getFoodPrice());
			pst.setInt(4, f.getFoodQuantity());
			pst.setString(5, f.getFoodCategory());
			pst.setString(6, f.getFoodDescription());
			pst.setInt(7, f.getFoodRating());
			pst.setInt(8, f.getFoodId());

			if (pst.executeUpdate() > 0)
				return true;

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				pst.close();
				con.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}

		}
		return false;
	}

	@Override
	public boolean deleteFood(Integer foodId) {

		try {
			con = DBConnection.makeConnection();
			sql = "delete from `Food_Maj` where foodId = ?";
			pst = con.prepareStatement(sql);
			pst.setInt(1, foodId);
			if (pst.executeUpdate() > 0)
				return true;

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				pst.close();
				con.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}

		}
		return false;
	}

	@Override
	public List<Food> searchFoodByCategory(String foodCategory) {
		con = DBConnection.makeConnection();
		sql = "select * from `Food_Maj` where foodCategory like ?";
		try {
			pst = con.prepareStatement(sql);
			pst.setString(1, "%" + foodCategory + "%");
			rs = pst.executeQuery();
			flist = new ArrayList<>();
			while (rs.next()) {
				f = new Food();
				f.setFoodId(rs.getInt("foodId"));
				f.setFoodName(rs.getString("foodName"));
				f.setFoodType(rs.getString("foodType"));
				f.setFoodPrice(rs.getDouble("foodPrice"));
				f.setFoodQuantity(rs.getInt("foodQuantity"));
				f.setFoodCategory(rs.getString("foodCategory"));
				f.setFoodDescription(rs.getString("foodDescription"));
				f.setFoodRating(rs.getInt("foodRating"));
				flist.add(f);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				rs.close();
				pst.close();
				con.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return flist;

	}

	@Override
	public List<Food> searchFoodByName(String foodName) {
		con = DBConnection.makeConnection();
		sql = "select * from `Food_Maj` where foodName like ?";
		try {
			pst = con.prepareStatement(sql);
			pst.setString(1, "%" + foodName + "%");
			rs = pst.executeQuery();
			flist = new ArrayList<>();
			while (rs.next()) {
				f = new Food();
				f.setFoodId(rs.getInt("foodId"));
				f.setFoodName(rs.getString("foodName"));
				f.setFoodType(rs.getString("foodType"));
				f.setFoodPrice(rs.getDouble("foodPrice"));
				f.setFoodQuantity(rs.getInt("foodQuantity"));
				f.setFoodCategory(rs.getString("foodCategory"));
				f.setFoodDescription(rs.getString("foodDescription"));
				f.setFoodRating(rs.getInt("foodRating"));
				flist.add(f);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				rs.close();
				pst.close();
				con.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return flist;
	}

	@Override
	public List<Food> searchFoodByType(String foodType) {
		con = DBConnection.makeConnection();
		sql = "select * from `Food_Maj` where foodType = ?";
		try {
			pst = con.prepareStatement(sql);
			pst.setString(1, foodType);
			rs = pst.executeQuery();
			flist = new ArrayList<>();
			while (rs.next()) {
				f = new Food();
				f.setFoodId(rs.getInt("foodId"));
				f.setFoodName(rs.getString("foodName"));
				f.setFoodType(rs.getString("foodType"));
				f.setFoodPrice(rs.getDouble("foodPrice"));
				f.setFoodQuantity(rs.getInt("foodQuantity"));
				f.setFoodCategory(rs.getString("foodCategory"));
				f.setFoodDescription(rs.getString("foodDescription"));
				f.setFoodRating(rs.getInt("foodRating"));
				flist.add(f);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				rs.close();
				pst.close();
				con.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return flist;
	}

	@Override
	public Food searchFoodById(Integer foodId) {
		try {
			con = DBConnection.makeConnection();
			sql = "SELECT * FROM `Food_Maj` WHERE foodId = ?";
			pst = con.prepareStatement(sql);
			pst.setInt(1, foodId);
			rs = pst.executeQuery();
			f = new Food();
			if (rs != null && rs.next()) {
				f.setFoodId(rs.getInt("foodId"));
				f.setFoodName(rs.getString("foodName"));
				f.setFoodType(rs.getString("foodType"));
				f.setFoodCategory(rs.getString("foodCategory"));
				f.setFoodType(rs.getString("foodType"));
				f.setFoodPrice(rs.getDouble("foodPrice"));
				f.setFoodDescription(rs.getString("foodDescription"));
				f.setFoodQuantity(rs.getInt("foodQuantity"));
				f.setFoodRating(rs.getInt("foodRating"));
			}
			return f;
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				rs.close();
				pst.close();
				con.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}

		return null;
	}

	@Override
	public List<Food> fetchAllFood() {

		try {
			con = DBConnection.makeConnection();
			sql = "SELECT * FROM `Food_Maj` ORDER BY foodName";
			pst = con.prepareStatement(sql);
			rs = pst.executeQuery();

			flist = new ArrayList<>();

			while (rs != null && rs.next()) {
				Food f = new Food(rs.getInt(1), rs.getString(2), rs.getString(3), rs.getDouble(4), rs.getInt(5),
						rs.getString(6), rs.getString(7), rs.getInt(8), rs.getString(9));
				flist.add(f);
			}

			return flist;

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				pst.close();
				con.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}

		return null;
	}

}
