package com.food.utility;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class Counts {

	// or use batch and one method

	Connection con = null;
	PreparedStatement ps = null;
	ResultSet rs = null;
	String sql = null;

	public int getUserCounts() {
		int count = 0;
		con = DBConnection.makeConnection();
		sql = "SELECT COUNT(`customerId`) FROM `Customer_Maj`";
		try {
			ps = con.prepareStatement(sql);
			rs = ps.executeQuery();
			while (rs.next()) {
				count = rs.getInt(1);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				ps.close();
				con.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}

		return count;
	}

	public int getProductCount() {
		int count = 0;
		con = DBConnection.makeConnection();
		sql = "SELECT COUNT(`foodId`) FROM `Food_Maj`";
		try {
			ps = con.prepareStatement(sql);
			rs = ps.executeQuery();
			while (rs.next()) {
				count = rs.getInt(1);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				ps.close();
				con.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}

		return count;
	}

	public int getOrdersCount() {
		int count = 0;
		con = DBConnection.makeConnection();
		sql = "SELECT COUNT(`orderId`) FROM `Order_Maj`";
		try {
			ps = con.prepareStatement(sql);
			rs = ps.executeQuery();
			while (rs.next()) {
				count = rs.getInt(1);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				ps.close();
				con.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}

		return count;
	}

	public int getCartItems(String customerEmail) {
		int count = 0;
		con = DBConnection.makeConnection();
		sql = "SELECT COUNT(`customerEmail`) FROM `Cart_Maj` WHERE `customerEmail` = ?";
		try {
			ps = con.prepareStatement(sql);
			ps.setString(1, customerEmail);
			rs = ps.executeQuery();
			while (rs.next()) {
				count = rs.getInt(1);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				ps.close();
				con.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}

		return count;
	}
}

// INSERT INTO `Cart_Maj` (`cartId`, `foodId`, `foodQuantity`, `price`, `subtotal`, `customerEmail`) VALUES (NULL, '4', '2', '80', '160', 'abdulkanoor@gmail.com');
